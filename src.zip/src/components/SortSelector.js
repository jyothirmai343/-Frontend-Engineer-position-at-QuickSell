import React from 'react';

const SortSelector = ({ setSort }) => {
  return (
    <div>
      <label>Sort by:</label>
      <select onChange={(e) => setSort(e.target.value)}>
        <option value="priority">Priority</option>
        <option value="title">Title</option>
      </select>
    </div>
  );
};

export default SortSelector;
