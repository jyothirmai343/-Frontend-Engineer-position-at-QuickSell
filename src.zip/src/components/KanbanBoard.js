import React from 'react';
import Card from './Card';
import { groupTickets, sortTickets } from '../utils/helpers';
import './KanbanBoard.css';

const KanbanBoard = ({ tickets, grouping, sort }) => {
  const groupedTickets = groupTickets(tickets, grouping);
  const sortedTickets = Object.entries(groupedTickets).reduce(
    (acc, [group, tickets]) => ({
      ...acc,
      [group]: sortTickets(tickets, sort),
    }),
    {}
  );

  return (
    <div className="kanban-board">
      {Object.entries(sortedTickets).map(([group, tickets]) => (
        <div key={group} className="kanban-column">
          <h2>{group}</h2>
          {tickets.map((ticket) => (
            <Card key={ticket.id} ticket={ticket} />
          ))}
        </div>
      ))}
    </div>
  );
};

export default KanbanBoard;
