// src/App.js
import React, { useState, useEffect } from 'react';
import KanbanBoard from './components/KanbanBoard';
import GroupSelector from './components/GroupSelector';
import SortSelector from './components/SortSelector';
import './App.css';

const App = () => {
  const [tickets, setTickets] = useState([]);
  const [grouping, setGrouping] = useState('status'); // Default group by status
  const [sort, setSort] = useState('priority'); // Default sort by priority

  // Fetch tickets from the API
  useEffect(() => {
    fetch('https://api.quicksell.co/v1/internal/frontend-assignment')
      .then((response) => response.json())
      .then((data) => setTickets(data.tickets))
      .catch((error) => console.error('Error fetching tickets:', error));
  }, []);

  return (
    <div className="App">
      <h1>Kanban Board</h1>
      <div className="controls">
        <GroupSelector setGrouping={setGrouping} />
        <SortSelector setSort={setSort} />
      </div>
      <KanbanBoard tickets={tickets} grouping={grouping} sort={sort} />
    </div>
  );
};

export default App;
