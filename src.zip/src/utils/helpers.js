export const groupTickets = (tickets, grouping) => {
    const groups = {};
    tickets.forEach((ticket) => {
      const key =
        grouping === 'user'
          ? ticket.assigned_to || 'Unassigned'
          : ticket[grouping] || 'No Priority';
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(ticket);
    });
    return groups;
  };
  
  export const sortTickets = (tickets, sort) => {
    return [...tickets].sort((a, b) => {
      if (sort === 'priority') {
        return b.priority - a.priority; // Descending priority
      }
      return a.title.localeCompare(b.title); // Ascending title
    });
  };
  